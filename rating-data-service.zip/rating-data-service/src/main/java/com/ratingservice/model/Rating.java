package com.ratingservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rating")
public class Rating {
	@Id
	private String ratingId;
	@Column(name = "movie_id")
	private String movieId;
	@Column(name = "userid")
	private String userId;
	@Column(name = "rating")
	private int rating;

	public Rating() {
	}

	public Rating(String ratingId, String movieId, String userId, int rating) {
		super();
		this.ratingId = ratingId;
		this.movieId = movieId;
		this.userId = userId;
		this.rating = rating;
	}

	public String getMovieId() {
		return movieId;
	}

	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getRatingId() {
		return ratingId;
	}

	public void setRatingId(String ratingId) {
		this.ratingId = ratingId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
