package com.ratingservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ratingservice.model.Rating;

@Repository
public interface RatingRepository extends JpaRepository<Rating, String>{
	//select * from rating where userid='user1';
	@Query(value="SELECT r FROM Rating r WHERE r.userId = ?1") 
	List<Rating> getUserRatings(String userId);

	@Query(value="SELECT r FROM Rating r WHERE r.movieId = ?1") 
	List<Rating> getRating(String movieId);

}
