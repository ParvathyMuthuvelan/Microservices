package com.ratingservice.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ratingservice.model.Rating;
import com.ratingservice.model.UserRating;
import com.ratingservie.service.RatingService;
@RestController
@RequestMapping("/ratingsdata")
public class RatingResource {
	
	@Autowired
	RatingService ratingService;
		@RequestMapping("/{movieId}")
		public List<Rating> getMovieInfo(@PathVariable String movieId)
		{
			
			List<Rating> rating=ratingService.getRating(movieId);
			return rating;
			//return new Rating(movieId,5);
		}
	
	
		@RequestMapping("/users/{userId}")
		public UserRating getUserRating(@PathVariable String userId)
		{
//			List<Rating> ratings=Arrays.asList(
//				new Rating("SP",4),
//				new Rating("MS",5)
//					);
			List<Rating> ratings=ratingService.getUserRatings(userId);
			UserRating userRating=new UserRating();
					userRating.setUserRating(ratings);
			return userRating;
		}
}
