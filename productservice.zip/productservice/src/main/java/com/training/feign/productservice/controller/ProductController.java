package com.training.feign.productservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.feign.AuthorizationClient;
import com.training.feign.productservice.model.User;

@RestController
public class ProductController {
	@Autowired
	private AuthorizationClient authorizingClient;
ProductController()
{}
	@GetMapping("/getAllProducts")
	public String getProducts(@RequestBody User user)
		 {
		if (authorizingClient.authenticate(user)) 
			return "valid";
			else 	return "Invalid";
		}
		

}
