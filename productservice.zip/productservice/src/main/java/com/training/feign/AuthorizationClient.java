package com.training.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.feign.productservice.model.User;

@FeignClient(name = "Authorization-Microservice", url = "${auth.URL}")
public interface AuthorizationClient {
	
	@PostMapping(value = "/authenticate")
	public boolean authenticate(@RequestBody User user);
}