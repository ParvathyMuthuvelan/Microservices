package com.movieinfo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.movieinfo.dao.MovieRepository;
import com.movieinfo.model.Movie;

@Service
public class MovieInfoService {
	@Autowired
	MovieRepository movieRepository;

	@Transactional
	public Movie getMovieInfo(String movieId) {
		Movie movie=null;
	Optional<Movie> optional=movieRepository.findById(movieId);
	if(optional.isPresent())
		movie=optional.get();
		return movie;
	}

}
