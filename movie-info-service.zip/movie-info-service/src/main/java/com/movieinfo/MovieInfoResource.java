package com.movieinfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.movieinfo.model.Movie;
import com.movieinfo.service.MovieInfoService;

@RestController
@RequestMapping("/movies")
public class MovieInfoResource {
	@Autowired
	MovieInfoService movieService;
	
	@RequestMapping("/{movieId}")
	public Movie getMovieInfo(@PathVariable String movieId)
	{
		//search for the movie Id and return the movie information
		Movie movie=movieService.getMovieInfo(movieId);
		return movie;
		//return new Movie(movieId,"SPotru");
	}

}
