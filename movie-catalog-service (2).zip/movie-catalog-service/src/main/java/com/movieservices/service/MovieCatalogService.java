package com.movieservices.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.movieservices.model.CatalogItem;
@Service
public class MovieCatalogService {

	public List<CatalogItem> getAllMovies() {
		List<CatalogItem> movieList=new ArrayList<>();
		movieList.add(new CatalogItem("Movie1","desc1",10));
		movieList.add(new CatalogItem("Movie2","desc2",5));
		return movieList;
	}

}
