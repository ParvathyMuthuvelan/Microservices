
package com.movieservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.movieservices.exceptions.AuthorizationException;
import com.movieservices.feign.AuthorisingClient;
import com.movieservices.model.CatalogItem;
import com.movieservices.service.MovieCatalogService;

@RestController

public class MovieCatalogResource {
	@Autowired
	private MovieCatalogService movieCatalogService;
	@Autowired
	private AuthorisingClient authorizingClient;
	@GetMapping("/getAllMovies")
	public List<CatalogItem> getCatalog(@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException 
	{
		if (authorizingClient.authorizeTheRequest(requestTokenHeader)) {
			return movieCatalogService.getAllMovies();
		} else {
			throw new AuthorizationException("Not allowed");
		}

			}
		
	

}
