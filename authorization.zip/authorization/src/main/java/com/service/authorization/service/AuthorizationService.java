package com.service.authorization.service;

import org.springframework.stereotype.Service;

import com.service.authorization.model.User;

@Service
public class AuthorizationService {

	public boolean valiateUser(User user) {
		boolean flag=false;
		if(user.getUsername().equals("admin")&&user.getPassword().equals("admin@123"))
				flag=true;
		return flag;
	
	}

}
