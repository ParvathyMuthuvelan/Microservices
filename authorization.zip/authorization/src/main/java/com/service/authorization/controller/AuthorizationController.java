package com.service.authorization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.authorization.model.User;
import com.service.authorization.service.AuthorizationService;

@RestController
public class AuthorizationController {
	@Autowired
	AuthorizationService authService;

	@PostMapping(value = "/authenticate")
	public boolean authenticate(@RequestBody User user) {
		boolean flag = false;
		flag = authService.valiateUser(user);
		return flag;
	}
}
