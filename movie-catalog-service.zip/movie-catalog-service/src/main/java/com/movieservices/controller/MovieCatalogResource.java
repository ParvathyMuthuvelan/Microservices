
package com.movieservices.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.movieservices.model.CatalogItem;
import com.movieservices.model.Movie;
import com.movieservices.model.Rating;
import com.movieservices.model.UserRating;
import com.movieservices.service.MovieCatalogService;

@RestController
//@CrossOrigin("http://192.168.0.186:3000")
public class MovieCatalogResource {
	
	@Autowired
	private RestTemplate restTemplate;
		@GetMapping("/getAllMovieCatalog/{userid}")
	public List<CatalogItem> getMessage(@PathVariable("userid") String userid)
	{
		List<CatalogItem> catalogList=new ArrayList<>();
		String movieId=null;
		Movie movie=null;
		CatalogItem item=null;
	UserRating userRating = restTemplate.getForObject("http://localhost:8082/ratingsdata/users/"+userid,
            UserRating.class);
	List<Rating> ratingList=userRating.getUserRating();
	for(Rating rating:ratingList)
	{
		movieId=rating.getMovieId();
	movie=restTemplate.getForObject("http://localhost:8081/movies/"+movieId, Movie.class);
	item =new CatalogItem(movie.getName(),movie.getDesc(),rating.getRating());
	catalogList.add(item);
	}
	
	return catalogList;
	}
	}


