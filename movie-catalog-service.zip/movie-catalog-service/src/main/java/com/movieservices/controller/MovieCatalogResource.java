
package com.movieservices.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.movieservices.model.CatalogItem;
import com.movieservices.model.Movie;
import com.movieservices.model.Rating;
import com.movieservices.model.UserRating;

@RestController
@RequestMapping("/catalog")
public class MovieCatalogResource {
	@Autowired
	RestTemplate restTemplate;
	@RequestMapping("/{userId}")
	public List<CatalogItem> getCatalog(@PathVariable("userId") String userId)
	{
		//http://localhost:8081/catalog/1
		//http://localhost:8083/ratingsdata/users/1
		UserRating ratings=restTemplate.getForObject("http://rating-data-service/ratingsdata/users/"+userId, UserRating.class);
//		List<Rating> ratings=Arrays.asList(
//				new Rating("SP",4),
//				new Rating("MS",5)
//				);
//		return Collections.singletonList(
//				new CatalogItem("SP","surya", 4)
//				//new CatalogItem( "SP", "surya", 4)
//				);
		List<CatalogItem> catalogList=new ArrayList<CatalogItem>();
		List<Rating> ratingList=ratings.getUserRating();
		System.out.println(ratingList);
		for(Rating obj:ratingList)
		{
		Movie movie=restTemplate.getForObject("http://movie-info-service/movies/"+obj.getMovieId(), Movie.class);
		CatalogItem item=new CatalogItem(movie.getName(),"desc",obj.getRating());
		catalogList.add(item);
		}
		return catalogList;
		
//		return new CatalogItem(movie.getName(),"desc",rating.getRating());
//		return ratings.getUserRating().stream().map(rating->
//		{
//			Movie movie=restTemplate.getForObject("http://movie-info-service/movies/"+rating.getMovieId(), Movie.class);
//			return new CatalogItem(movie.getName(),"desc",rating.getRating());
//		}).collect(Collectors.toList());
//		
		}
		
	

}
